<?php

class User_model extends CI_Model
{
    private $_tableName = "tbl_user";

    // QUERY MENAMPILKAN DAFTAR diameter
    function daftar_user()
    {
        $result = $this->db->query('select * from tbl_user');
        return $result;
    }    

    // QUERY MENGECEK diameter
    function check_username($username)
    {
        $this->db->where("username", $username);
        $query = $this->db->get($this->_tableName);
        if ($query->num_rows() > 0) {
            return true;
        } else {
            return false;
        }
    }
    
    function check_username2($where)
    {
        $this->db->where($where);
        $query = $this->db->get($this->_tableName);
        if ($query->num_rows() > 0) {
            return true;
        } else {
            return false;
        }
    }

    //QUERY MENGHAPUS diameter
    function hapus_user($id)
    {
        $this->db->where("id", $id);
        $this->db->delete($this->_tableName);
    }

    //QUERY MENGEDIT diameter
    function edit_user($id, $data)
    {
        $this->db->where('id', $id);
        $this->db->update($this->_tableName, $data);
    }

    //QUERY MENAMBAH diameter
    function input_user($data)
    {
        $this->db->insert($this->_tableName, $data);
    }    

    function cek_login($where)
    {
        return $this->db->get_where($this->_tableName, $where);
    }
}
