<?php

class Guru_model extends CI_Model
{
    private $_tableName = "tbl_guru";

    // QUERY MENAMPILKAN DAFTAR diameter
    function daftar_guru()
    {
        $result = $this->db->query('SELECT g.*, if(g.jenis_kelamin = "L", "Laki - Laki", "Perempuan") jns_kelamin, u.id id_user FROM tbl_guru g INNER JOIN tbl_user u ON g.nig = u.username');
        return $result;
    }

    // QUERY MENGECEK diameter
    function check_nig($nig)
    {
        $this->db->where("nig", $nig);
        $query = $this->db->get($this->_tableName);
        if ($query->num_rows() > 0) {
            return true;
        } else {
            return false;
        }
    }
    
    function check_nig2($where)
    {
        $this->db->where($where);
        $query = $this->db->get($this->_tableName);
        if ($query->num_rows() > 0) {
            return true;
        } else {
            return false;
        }
    }

    function get_guru($username)
    {
        $this->db->where("nig", $username);
        return $this->db->get($this->_tableName);        
    }

    //QUERY MENGHAPUS diameter
    function hapus_guru($id)
    {
        $this->db->where("id", $id);
        $this->db->delete($this->_tableName);
    }

    //QUERY MENGEDIT diameter
    function edit_guru($id, $data)
    {
        $this->db->where('id', $id);
        $this->db->update($this->_tableName, $data);
    }

    //QUERY MENAMBAH diameter
    function input_guru($data)
    {
        $this->db->insert($this->_tableName, $data);
    }    
}
