<?php

class Siswa_model extends CI_Model
{
    private $_tableName = "tbl_siswa";

    // QUERY MENAMPILKAN DAFTAR diameter
    function daftar_siswa()
    {
        $result = $this->db->query('SELECT s.*, if(s.jenis_kelamin = "L", "Laki - Laki", "Perempuan") jns_kelamin, s.id id_user FROM tbl_siswa s INNER JOIN tbl_user u ON s.nis = u.username');
        return $result;
    }

    // QUERY MENGECEK diameter
    function check_nis($nis)
    {
        $this->db->where("nis", $nis);
        $query = $this->db->get($this->_tableName);
        if ($query->num_rows() > 0) {
            return true;
        } else {
            return false;
        }
    }
    
    function check_nis2($where)
    {
        $this->db->where($where);
        $query = $this->db->get($this->_tableName);
        if ($query->num_rows() > 0) {
            return true;
        } else {
            return false;
        }
    }

    function get_siswa($username)
    {
        $this->db->where("nis", $username);
        return $this->db->get($this->_tableName);        
    }

    //QUERY MENGHAPUS diameter
    function hapus_siswa($id)
    {
        $this->db->where("id", $id);
        $this->db->delete($this->_tableName);
    }

    //QUERY MENGEDIT diameter
    function edit_siswa($id, $data)
    {
        $this->db->where('id', $id);
        $this->db->update($this->_tableName, $data);
    }

    //QUERY MENAMBAH diameter
    function input_siswa($data)
    {
        $this->db->insert($this->_tableName, $data);
    }    
}
