<?php

class Kelas_model extends CI_Model
{
    private $_tableName = "tbl_kelas";
    private $_tableNameMateri = "tbl_materi";
    private $_tableNameKelasSiswa = "tbl_kelas_siswa";

    // QUERY MENAMPILKAN DAFTAR diameter
    function daftar_kelas($is_admin, $id_guru)
    {
        $result = $this->db->query("SELECT k.*, g.nama nama_guru, (SELECT IFNULL(COUNT(*),0) jmh_materi FROM tbl_materi WHERE id_kelas = k.id) jmh_kelas FROM `tbl_kelas` k INNER JOIN tbl_guru g ON k.id_guru = g.id WHERE IF( 0 <> $is_admin, g.nig = '$id_guru', TRUE)");
        return $result;
    }

    function detail_kelas($id)
    {
        $result = $this->db->query("SELECT k.*, g.nama nama_guru FROM `tbl_kelas` k INNER JOIN tbl_guru g ON k.id_guru = g.id WHERE k.id = '$id'");
        return $result;
    }

    //QUERY MENGHAPUS KELAS
    function hapus_kelas($id)
    {
        $this->db->where("id", $id);
        $this->db->delete($this->_tableName);
    }

    //QUERY MENGEDIT diameter
    function edit_kelas($id, $data)
    {
        $this->db->where('id', $id);
        $this->db->update($this->_tableName, $data);
    }

    //QUERY MENAMBAH KELAS
    function input_kelas($data)
    {
        $this->db->insert($this->_tableName, $data);
    }

    //QUERY MENAMBAH materi
    function input_materi($data)
    {
        $this->db->insert($this->_tableNameMateri, $data);
    }

    //QUERY MENGEDIT MATERI
    function edit_materi($id, $data)
    {
        $this->db->where('id', $id);
        $this->db->update($this->_tableNameMateri, $data);
    }

    function daftar_materi($id_kelas)
    {
        $result = $this->db->query("SELECT * FROM tbl_materi WHERE id_kelas = '$id_kelas' ORDER BY tgl_materi ASC");
        return $result;
    }
    
    function detail_materi($id_materi)
    {
        $result = $this->db->query("SELECT * FROM tbl_materi WHERE id = '$id_materi'");
        return $result;
    }

    //QUERY MENGHAPUS KELAS
    function hapus_materi($id_materi)
    {
        $this->db->where("id", $id_materi);
        $this->db->delete($this->_tableNameMateri);
    }

    function daftar_siswa_kelas($id_kelas)
    {
        $result = $this->db->query("SELECT s.*, ks.tgl_gabung FROM tbl_kelas_siswa ks INNER JOIN tbl_siswa s ON ks.id_siswa = s.id WHERE ks.id_kelas = '$id_kelas'");
        return $result;
    }

    //QUERY MENAMBAH SISWA DI KELAS
    function input_siswa_kelas($data)
    {
        $this->db->insert($this->_tableNameKelasSiswa, $data);
    }


    // QUERY UNTUK ROLE SISWA
    function daftar_kelas_by_siswa($id_siswa){
        $result = $this->db->query("SELECT k.*, ks.tgl_gabung, g.nama nama_guru, (SELECT IFNULL(COUNT(*),0) jmh_materi FROM tbl_materi WHERE id_kelas = k.id) jmh_kelas FROM tbl_kelas_siswa ks INNER JOIN tbl_kelas k ON k.id = ks.id_kelas INNER JOIN tbl_guru g ON k.id_guru = g.id WHERE ks.id_siswa = '$id_siswa'");
        return $result;        
    }

    function check_kelas($kode_kelas)
    {
        $this->db->where("kode_kelas", $kode_kelas);
        $query = $this->db->get($this->_tableName);
        if ($query->num_rows() > 0) {
            return $query;
        } else {
            return false;
        }
    }
}
