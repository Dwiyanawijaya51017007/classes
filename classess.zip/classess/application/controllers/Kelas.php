<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Kelas extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        // $this->isLoggedAdminIn();
        $this->load->model('Kelas_model');
        $this->load->model('Guru_model');
        $this->load->model('Siswa_model');
    }

    public function index()
    {
        $is_admin = $this->getRole() === "Admin" ? 0 : 1;
        $data['daftar_kelas'] = $this->Kelas_model->daftar_kelas($is_admin, $this->session->userdata('username'))->result();
        $data['daftar_guru'] = $this->Guru_model->daftar_guru()->result();
        $this->load->template('daftar_kelas', $data);
    }

    public function detail_kelas($id_kelas)
    {
        $data['detail_kelas'] = $this->Kelas_model->detail_kelas($id_kelas)->row_array();
        $data['daftar_materi'] = $this->Kelas_model->daftar_materi($id_kelas)->result();
        $data['daftar_siswa'] = $this->Siswa_model->daftar_siswa()->result();
        $data['daftar_siswa_kelas'] = $this->Kelas_model->daftar_siswa_kelas($id_kelas)->result();
        $this->load->template('detail_kelas', $data);
    }

    public function detail_materi_edit($id_materi, $id_kelas)
    {
        $data['id_kelas'] = $id_kelas;
        $data['detail_materi'] = $this->Kelas_model->detail_materi($id_materi)->row_array();        
        $this->load->template('edit_materi', $data);
    }

    function generateRandomString($length = 10)
    {
        $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $charactersLength = strlen($characters);
        $randomString = '';
        for ($i = 0; $i < $length; $i++) {
            $randomString .= $characters[rand(0, $charactersLength - 1)];
        }
        return $randomString;
    }

    // CONTROLLER TAMBAH KELAS BARU
    public function tambah_kelas()
    {
        $id_guru = $this->getRole() === "Admin" ? $this->input->post('id_guru') : $this->session->userdata('id_guru_siswa');
        $nama_kelas = $this->input->post('nama_kelas');
        $tgl_mulai = $this->input->post('tgl_mulai');

        $data = array(
            'id' => $this->uuid->v4(),
            'kode_kelas' => $this->generateRandomString(5),
            'judul' => $nama_kelas,
            'tgl_mulai' => $tgl_mulai,
            'id_guru' => $id_guru,
            'create_date' => date('Y-m-d h:i:s'),
            'create_by' => $this->getIdUser()
        );

        $result2 = $this->Kelas_model->input_kelas($data);
        if ($result2) {
            $this->session->set_flashdata('error', 'Data gagal disimpan');
            redirect(base_url('Kelas'));
        } else {
            $this->session->set_flashdata('success', 'Kelas Berhasil Ditambahkan');
            redirect(base_url('Kelas'));
        }
    }

    public function edit_kelas()
    {
        $id = $this->input->post('id_kelas');
        $id_guru = $this->getRole() === "Admin" ? $this->input->post('id_guru') : $this->session->userdata('id_guru_siswa');
        $nama_kelas = $this->input->post('nama_kelas');
        $tgl_mulai = $this->input->post('tgl_mulai');

        $data = array(
            'id_guru' => $id_guru,
            'judul' => $nama_kelas,
            'tgl_mulai' => $tgl_mulai,
            'update_date' => date('Y-m-d h:i:s'),
            'update_by' => $this->getIdUser()
        );

        $result2 = $this->Kelas_model->edit_kelas($id, $data);
        if ($result2) {
            $this->session->set_flashdata('error', 'Data gagal diupdate');
            redirect(base_url('Kelas'));
        } else {
            $this->session->set_flashdata('success', 'Kelas Berhasil Diupdate');
            redirect(base_url('Kelas'));
        }
    }

    // CONTROLLER MENGHAPUS Kelas
    public function hapus_kelas($id)
    {
        $result2 = $this->Kelas_model->hapus_kelas($id);

        if ($result2) {
            $this->session->set_flashdata('error', 'Data gagal dihapus');
            redirect(base_url('Kelas'));
        } else {
            $this->session->set_flashdata('success', 'Kelas Berhasil Dihapus');
            redirect(base_url('Kelas'));
        }
    }

    // CONTROLLER TAMBAH MATERI BARU
    public function tambah_materi()
    {
        $id_kelas = $this->input->post('id_kelas');
        $judul_materi = $this->input->post('judul_materi');
        $tgl_materi = $this->input->post('tgl_materi');
        $deskripsi = $this->input->post('deskripsi');
        $jenis_materi = $this->input->post('jenis_materi');

        $data = array(
            'id' => $this->uuid->v4(),
            'id_kelas' => $id_kelas,
            'judul_materi' => $judul_materi,
            'tgl_materi' => $tgl_materi,
            'jenis_materi' => $jenis_materi,
            'deskripsi' => $deskripsi,
            'create_date' => date('Y-m-d h:i:s'),
            'create_by' => $this->getIdUser()
        );

        $result2 = $this->Kelas_model->input_materi($data);
        if ($result2) {
            $this->session->set_flashdata('error', 'Data gagal disimpan');
            redirect(base_url('Kelas/detail_kelas/' . $id_kelas));
        } else {
            $this->session->set_flashdata('success', 'Materi Berhasil Ditambahkan');
            redirect(base_url('Kelas/detail_kelas/' . $id_kelas));
        }
    }

    // CONTROLLER EDIT MATERI
    public function edit_materi()
    {
        $id_kelas = $this->input->post('id_kelas');
        $id_materi = $this->input->post('id_materi');
        $judul_materi = $this->input->post('judul_materi');
        $tgl_materi = $this->input->post('tgl_materi');
        $deskripsi = $this->input->post('deskripsi');
        $jenis_materi = $this->input->post('jenis_materi');

        $data = array(
            'judul_materi' => $judul_materi,
            'tgl_materi' => $tgl_materi,
            'jenis_materi' => $jenis_materi,
            'deskripsi' => $deskripsi,
            'update_date' => date('Y-m-d h:i:s'),
            'update_by' => $this->getIdUser()
        );

        $result2 = $this->Kelas_model->edit_materi($id_materi, $data);
        if ($result2) {
            $this->session->set_flashdata('error', 'Data gagal disimpan');
            redirect(base_url('Kelas/detail_kelas/' . $id_kelas));
        } else {
            $this->session->set_flashdata('success', 'Materi Berhasil Diupdate');
            redirect(base_url('Kelas/detail_kelas/' . $id_kelas));
        }
    }

    // CONTROLLER MENGHAPUS Kelas
    public function hapus_materi($id_materi, $id_kelas)
    {
        $result2 = $this->Kelas_model->hapus_materi($id_materi);

        if ($result2) {
            $this->session->set_flashdata('error', 'Data gagal dihapus');
            redirect(base_url('Kelas/detail_kelas/' . $id_kelas));
        } else {
            $this->session->set_flashdata('success', 'Materi Berhasil Dihapus');
            redirect(base_url('Kelas/detail_kelas/' . $id_kelas));
        }
    }


    // CONTROLLER TAMBAH SISWA BARU DI KELAS
    public function tambah_siswa_kelas()
    {
        $id_kelas = $this->input->post('id_kelas');
        $id_siswa = $this->input->post('id_siswa');

        $data = array(
            'id' => $this->uuid->v4(),
            'id_kelas' => $id_kelas,
            'id_siswa' => $id_siswa,
            'tgl_gabung' => date('Y-m-d h:i:s')
        );

        $result2 = $this->Kelas_model->input_siswa_kelas($data);
        if ($result2) {
            $this->session->set_flashdata('error', 'Data gagal disimpan');
            redirect(base_url('Kelas/detail_kelas/' . $id_kelas));
        } else {
            $this->session->set_flashdata('success', 'Siswa Berhasil Ditambahkan');
            redirect(base_url('Kelas/detail_kelas/' . $id_kelas));
        }
    }

    // CONTROLLER KELAS SISWA
    public function daftar_kelas_by_siswa()
    {
        $data['daftar_kelas'] = $this->Kelas_model->daftar_kelas_by_siswa($this->session->userdata('id_guru_siswa'))->result();
        $this->load->template('daftar_kelas_siswa', $data);
    }

    public function gabung_kelas()
    {
        $kode_kelas = $this->input->post('kode_kelas');


        $result2 = $this->Kelas_model->check_kelas($kode_kelas);
        if (!$result2) {
            $this->session->set_flashdata('error', 'Kode Kelas tidak ditemukan');
            redirect(base_url('kelas_saya'));
        } else {            
            $data = array(
                'id' => $this->uuid->v4(),
                'id_kelas' => $result2->row_array()["id"],
                'id_siswa' => $this->session->userdata('id_guru_siswa'),
                'tgl_gabung' => date('Y-m-d h:i:s')
            );
            $result = $this->Kelas_model->input_siswa_kelas($data);
            $this->session->set_flashdata('success', 'Berhasil memasukkan kode kelas');
            redirect(base_url('kelas_saya'));
        }
    }

    public function detail_kelas_siswa($id_kelas)
    {
        $data['detail_kelas'] = $this->Kelas_model->detail_kelas($id_kelas)->row_array();
        $data['daftar_materi'] = $this->Kelas_model->daftar_materi($id_kelas)->result();
        $this->load->template('detail_kelas_siswa', $data);
    }
}
