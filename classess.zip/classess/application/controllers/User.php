<?php
defined('BASEPATH') or exit('No direct script access allowed');

class User extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->model('User_model');
        $this->load->library('form_validation');
    }

    public function index()
    {
        //$this->isLoggedAdminIn();
        $data['daftar_user'] = $this->User_model->daftar_user()->result();
        $this->load->template('daftar_user', $data);
    }

    public function login()
    {
        $this->load->view('login');
    }

    public function autentikasi()
    {
        $this->form_validation->set_rules('username', 'Username', 'required');
        $this->form_validation->set_rules('password', 'Password', 'required');

        $username = $this->input->post('username');
        $password = $this->input->post('password');

        if ($this->form_validation->run() == FALSE) {
            $this->session->set_flashdata('error', 'Username / Password belum diisi');
            redirect('login');
        } else {
            $where = array(
                'username' => $username,
                'password' => md5($password)
            );
            $cek = $this->User_model->cek_login($where)->num_rows();
            if ($cek > 0) {

                $result = $this->User_model->cek_login($where)->result();

                if ($result[0]->role === "Guru") {
                    $this->load->model('Guru_model');
                    $id_guru_or_siswa = $this->Guru_model->get_guru($result[0]->username)->row_array()['id'];
                } else if ($result[0]->role === "Siswa") {
                    $this->load->model('Siswa_model');
                    $id_guru_or_siswa = $this->Siswa_model->get_siswa($result[0]->username)->row_array()['id'];
                }

                $data_session = array(
                    'role' => $result[0]->role,
                    'id' => $result[0]->id,
                    'nama_user' => $result[0]->nama,
                    'username' => $result[0]->username,
                    'id_guru_siswa' => $id_guru_or_siswa
                );
            
                $this->session->set_userdata($data_session);

                redirect(base_url());
            } else {
                $this->session->set_flashdata('error', 'Username atau password salah !');
                redirect(base_url('login'));
            }
        }
    }

    public function aksi_login()
    {
        $email = $this->input->post('email');
        $password = $this->input->post('password');

        if ($email == null || $password == null) {
            $this->session->set_flashdata('error', 'Email atau password belum diisi !');
            redirect(base_url('login'));
        } else {
        }
    }

    public function logout()
    {
        $this->session->sess_destroy();
        redirect(base_url('login'));
    }

    public function access_denied()
    {
        $this->load->template('access_denied');
    }

    public function tambah_user()
    {
        $nama = $this->input->post('nama');
        $username = $this->input->post('username');
        $password = $this->input->post('password');
        $role = $this->input->post('role');

        $data = array(
            'id' => $this->uuid->v4(),
            'nama' => $nama,
            'username' => $username,
            'password' => MD5($password),
            'role' => $role,
            'create_date' => date("Y-m-s"),
            'create_by' => "1",
        );

        $where = array(
            'username' => $username
        );

        $result = $this->User_model->check_username2($where);

        if ($result) {
            echo $this->session->set_flashdata('error', 'Username telah terinput');
            redirect(base_url('User'));
        } else {
            $result2 = $this->User_model->input_user($data);
            if ($result2) {
                $this->session->set_flashdata('error', 'Data gagal disimpan');
                redirect(base_url('User'));
            } else {
                $this->session->set_flashdata('success', 'User Berhasil Ditambahkan');
                redirect(base_url('User'));
            }
        }
    }

    public function edit_user()
    {
        $id = $this->input->post('id_user');
        $nama = $this->input->post('nama');
        $username = $this->input->post('username');
        $password = $this->input->post('password');
        $role = $this->input->post('role');

        if (isset($password)) {
            $data = array(
                'nama' => $nama,
                'username' => $username,
                'password' => MD5($password),
                'role' => $role,
                'update_date' => date("Y-m-s"),
                'update_by' => "1",
            );
        } else {
            $data = array(
                'nama' => $nama,
                'username' => $username,
                'role' => $role,
                'update_date' => date("Y-m-s"),
                'update_by' => "1",
            );
        }

        $where = array(
            'id !=' => $id,
            'username' => $username
        );

        $result = $this->User_model->check_username2($where);

        if ($result) {
            echo $this->session->set_flashdata('error', 'Username telah terinput');
            redirect(base_url('User'));
        } else {
            $result2 = $this->User_model->edit_user($id, $data);
            if ($result2) {
                $this->session->set_flashdata('error', 'Data gagal diupdate');
                redirect(base_url('User'));
            } else {
                $this->session->set_flashdata('success', 'User Berhasil Diupdate');
                redirect(base_url('User'));
            }
        }
    }

    // CONTROLLER MENGHAPUS Diameter
    public function hapus_user($id)
    {
        $result2 = $this->User_model->hapus_user($id);

        if ($result2) {
            $this->session->set_flashdata('error', 'Data gagal dihapus');
            redirect(base_url('User'));
        } else {
            $this->session->set_flashdata('success', 'User Berhasil Dihapus');
            redirect(base_url('User'));
        }
    }
}
