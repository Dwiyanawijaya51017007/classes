<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Guru extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        // $this->isLoggedAdminIn();
        $this->load->model('Guru_model');
    }

    public function index()
    {
        $data['daftar_guru'] = $this->Guru_model->daftar_guru()->result();
        $this->load->template('daftar_guru', $data);
    }

    // CONTROLLER TAMBAH Guru BARU
    public function tambah_guru()
    {
        $nig = $this->input->post('nig');
        $nama = $this->input->post('nama');
        $tempat_lahir = $this->input->post('tempat_lahir');
        $tanggal_lahir = $this->input->post('tanggal_lahir');
        $jenis_kelamin = $this->input->post('jenis_kelamin');
        $alamat = $this->input->post('alamat');
        $password = $this->input->post('password');

        $data = array(
            'id' => $this->uuid->v4(),
            'nig' => $nig,
            'nama' => $nama,
            'tempat_lahir' => $tempat_lahir,
            'tanggal_lahir' => $tanggal_lahir,
            'jenis_kelamin' => $jenis_kelamin,
            'alamat' => $alamat,
            'create_date' => date('Y-m-d h:i:s'),
            'create_by' => $this->getIdUser()
        );

        $data_user = array(
            'id' => $this->uuid->v4(),
            'nama' => $nama,
            'username' => $nig,
            'password' => MD5($password),
            'role' => "Guru",
            'create_date' => date('Y-m-d h:i:s'),
            'create_by' => $this->getIdUser()
        );

        $result = $this->Guru_model->check_nig($nig);

        if ($result) {
            echo $this->session->set_flashdata('error', 'NIG telah terinput');
            redirect(base_url('Guru'));
        } else {
            $result2 = $this->Guru_model->input_guru($data);
            if ($result2) {
                $this->session->set_flashdata('error', 'Data gagal disimpan');
                redirect(base_url('Guru'));
            } else {
                $this->load->model('User_model');
                $this->User_model->input_user($data_user);
                $this->session->set_flashdata('success', 'Guru Berhasil Ditambahkan');
                redirect(base_url('Guru'));
            }
        }
    }

    public function edit_guru()
    {
        $id = $this->input->post('id_guru');
        $id_user = $this->input->post('id_user');
        $nig = $this->input->post('nig');
        $nama = $this->input->post('nama');
        $tempat_lahir = $this->input->post('tempat_lahir');
        $tanggal_lahir = $this->input->post('tanggal_lahir');
        $jenis_kelamin = $this->input->post('jenis_kelamin');
        $alamat = $this->input->post('alamat');
        $password = $this->input->post('password');

        $data = array(
            'nig' => $nig,
            'nama' => $nama,
            'tempat_lahir' => $tempat_lahir,
            'tanggal_lahir' => $tanggal_lahir,
            'jenis_kelamin' => $jenis_kelamin,
            'alamat' => $alamat,
            'update_date' => date('Y-m-d h:i:s'),
            'update_by' => $this->getIdUser()
        );        

        $where = array(
            'id !=' => $id,
            'nig' => $nig
        );        

        $result = $this->Guru_model->check_nig2($where);

        if ($result) {
            echo $this->session->set_flashdata('error', 'NIG telah terinput');
            redirect(base_url('Guru'));
        } else {
            $result2 = $this->Guru_model->edit_guru($id, $data);
            if ($result2) {
                $this->session->set_flashdata('error', 'Data gagal diupdate');
                redirect(base_url('Guru'));
            } else {
                if(isset($password)){
                    $data_user = array(
                        'username' => $nig,
                        'nama' => $nama,
                        'password' => MD5($password),
                        'update_date' => date('Y-m-d h:i:s'),
                        'update_by' => $this->getIdUser()
                    );          
                }else{
                    $data_user = array(
                        'username' => $nig,
                        'nama' => $nama,
                        'update_date' => date('Y-m-d h:i:s'),
                        'update_by' => $this->getIdUser()
                    );          
                }
        
                $where_user = array(
                    'id' => $id_user            
                );
                $this->load->model('User_model');
                $this->User_model->edit_user($id_user, $data_user);
                $this->session->set_flashdata('success', 'Guru Berhasil Diupdate');
                redirect(base_url('Guru'));
            }
        }
    }

    // CONTROLLER MENGHAPUS Guru
    public function hapus_guru($id)
    {
        $result2 = $this->Guru_model->hapus_guru($id);

        if ($result2) {
            $this->session->set_flashdata('error', 'Data gagal dihapus');
            redirect(base_url('Guru'));
        } else {
            $this->session->set_flashdata('success', 'Guru Berhasil Dihapus');
            redirect(base_url('Guru'));
        }
    }
}
