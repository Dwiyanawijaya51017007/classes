<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1>Kelas</h1>
        </div>
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="<?php echo base_url() ?>">Home</a></li>
            <li class="breadcrumb-item active">Kelas</li>
          </ol>
        </div>
      </div>
    </div><!-- /.container-fluid -->
  </section>

  <!-- Main content -->
  <section class="content">
    <div class="row">
      <div class="col-lg-12">
        <!-- /.card -->
        <div class="card">
          <div class="card-header">
            <div class="row">
              <h3 class="col-lg-6 col-md-6 col-sm-6 col-xs-12">Kelas</h3>
              <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                <button class="btn btn-primary float-right" data-toggle="modal" data-target="#modal-tambah-kelas">Tambah Kelas</button>
              </div>
            </div>
          </div>
          <div class="card-body table-responsive">
            <table class="table table-bordered table-striped example3">
              <thead>
                <tr>
                  <th>No</th>
                  <th>Kelas</th>
                  <th>Tanggal Kelas</th>
                  <th>Kode Kelas</th>
                  <th>Jumlah Materi</th>
                  <th>Guru</th>
                  <th>Aksi</th>
                </tr>
              </thead>
              <tbody>
                <?php
                $no = 1;
                foreach ($daftar_kelas as $u) { ?>
                  <tr>
                    <td class="text-center"><?php echo $no++ ?></td>
                    <td class="text-center"><?php echo $u->judul ?></td>
                    <td class="text-center"><?php echo $u->tgl_mulai ?></td>
                    <td class="text-center"><?php echo $u->kode_kelas ?></td>
                    <td class="text-center"><?php echo $u->jmh_kelas ?></td>
                    <td class="text-center"><?php echo $u->nama_guru ?></td>
                    <td class="text-center">
                      <a class="btn btn-sm btn-primary" href="<?php echo base_url() . 'Kelas/detail_kelas/' . $u->id ?>"><i class="fa fa-eye"></i></a>
                      <a class="btn btn-sm btn-warning" data-toggle="modal" data-target=#modal-edit-kelas onClick="editguru('<?php echo $u->id ?>', '<?php echo $u->id_guru ?>', '<?php echo $u->judul ?>', '<?php echo $u->tgl_mulai ?>')" href="#"><i class="fa fa-pencil-alt"></i></a>
                      <a class="btn btn-sm btn-danger" onclick="javascript: return confirm('Apakah Anda yakin ingin hapus kelas ini?')" href="<?php echo base_url() . 'Kelas/hapus_kelas/' . $u->id ?>"><i class="fa fa-trash"></i></a>
                    </td>
                  </tr>
                <?php } ?>
              </tbody>
            </table>
          </div>
          <!-- /.card-body -->
        </div>
        <!-- /.card -->
      </div>
    </div>
    <!-- /.row -->
  </section>
  <!-- /.content -->
</div>
<!-- /.content-wrapper -->

<script>
  function editguru(id, id_guru, nama_kelas, tgl_mulai) {
    // document.getElementById(id_guru).selected = "true";
    document.getElementById('id_kelas').value = id;
    document.getElementById('nama_kelas').value = nama_kelas;
    document.getElementById('tgl_mulai').value = tgl_mulai;
    $('#id_guru').val(id_guru).trigger('change');
  }
</script>

<div class="modal fade" id="modal-tambah-kelas">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title">Tambah Kelas</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <form action="<?php echo base_url() ?>Kelas/tambah_kelas" role="form" method="post">
        <div class="modal-body">
          <div class="form-group">
            <label>Nama Kelas</label>
            <input type="text" class="form-control" name="nama_kelas" required>
          </div>
          <div class="form-group">
            <label>Tanggal Mulai</label>
            <input type="date" class="form-control" name="tgl_mulai" required>
          </div>
          <?php if ($this->session->userdata('role') !== "Guru" && $this->session->userdata('role') === "Admin") { ?>
            <div class="form-group">
              <label>Guru</label>
              <select class="form-control select2" style="width: 100%;" name="id_guru">
                <?php
                $no = 1;
                foreach ($daftar_guru as $u) { ?>
                  <option value="<?php echo $u->id ?>"><?php echo $u->nama ?></option>
                <?php } ?>
              </select>
            </div>
          <?php } ?>
        </div>
        <div class="modal-footer justify-content-between">
          <button type="button" class="btn btn-default" data-dismiss="modal">Tutup</button>
          <button type="submit" class="btn btn-primary">Simpan</button>
        </div>
      </form>
    </div>
    <!-- /.modal-content -->
  </div>
  <!-- /.modal-dialog -->
</div>
<!-- /.modal -->

<div class="modal fade" id="modal-edit-kelas">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title">Edit Kelas</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <form action="<?php echo base_url() ?>Kelas/edit_kelas" role="form" method="post">
        <div class="modal-body">
          <div class="form-group">
            <label>Nama Kelas</label>
            <input type="text" class="form-control" id="nama_kelas" name="nama_kelas" required>
            <input type="text" class="form-control" id="id_kelas" name="id_kelas" required hidden>
          </div>
          <div class="form-group">
            <label>Tanggal Mulai</label>
            <input type="date" class="form-control" id="tgl_mulai" name="tgl_mulai" required>
          </div>          

          <?php if ($this->session->userdata('role') !== "Guru" && $this->session->userdata('role') === "Admin") { ?>
            <div class="form-group">
              <label>Guru</label>
              <select class="form-control select2" id="id_guru" style="width: 100%;" name="id_guru">
                <?php
                $no = 1;
                foreach ($daftar_guru as $u) { ?>
                  <option id="<?php echo $u->id ?>" value="<?php echo $u->id ?>"><?php echo $u->nama ?></option>
                <?php } ?>
              </select>
            </div>
          <?php } ?>
        </div>
        <div class="modal-footer justify-content-between">
          <button type="button" class="btn btn-default" data-dismiss="modal">Tutup</button>
          <button type="submit" class="btn btn-primary">Simpan</button>
        </div>
      </form>
    </div>
    <!-- /.modal-content -->
  </div>
  <!-- /.modal-dialog -->
</div>
<!-- /.modal -->