<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1>Edit Materi</h1>
        </div>
      </div>
    </div><!-- /.container-fluid -->
  </section>

  <!-- Main content -->
  <section class="content">
    <div class="row">
      <div class="col-lg-12">
        <div class="card">
          <div class="card-header">
            <div class="row">
              <div class="col-lg-12 col-md-6 col-sm-6 col-xs-12">
                <form action="<?php echo base_url() ?>Kelas/edit_materi" role="form" method="post">
                  <div class="form-group">
                    <label>Judul Materi</label>
                    <input type="text" class="form-control" name="judul_materi" value="<?php echo $detail_materi['judul_materi'] ?>" required>
                    <input type="text" class="form-control" name="id_kelas" value="<?php echo $this->uri->segment(4) ?>" required hidden>
                    <input type="text" class="form-control" name="id_materi" value="<?php echo $this->uri->segment(3) ?>" required hidden>
                  </div>
                  <div class="form-group">
                    <label>Tanggal Materi</label>
                    <input type="date" class="form-control" name="tgl_materi" value="<?php echo $detail_materi['tgl_materi'] ?>" required>
                  </div>
                  <div class="form-group">
                    <label class="text-black" for="nama">Jenis</label> <br>
                    <div class="custom-control custom-radio custom-control-inline">
                      <input type="radio" checked id="rb_materi" name="jenis_materi" value="Materi" class="custom-control-input" <?php if($detail_materi['jenis_materi'] === "Materi") {echo "selected";} ?>>
                      <label class="custom-control-label" for="rb_materi">Materi</label>
                    </div>
                    <div class="custom-control custom-radio custom-control-inline">
                      <input type="radio" id="rb_tugas" name="jenis_materi" value="Tugas" class="custom-control-input" <?php if($detail_materi['jenis_materi'] === "Tugas") {echo "selected";} ?>>
                      <label class="custom-control-label" for="rb_tugas">Tugas</label>
                    </div>
                  </div>
                  <div class="form-group">
                    <label>Deskripsi</label>
                    <div class="mb-3">
                      <textarea class="textarea" name="deskripsi" placeholder="Place some text here" style="width: 100%; height: 300px; font-size: 14px; line-height: 30px; border: 1px solid #dddddd; padding: 10px;"><?php echo $detail_materi['deskripsi'] ?></textarea>
                    </div>
                  </div>
                  <a class="btn btn-danger" href="<?php echo base_url("Kelas/detail_kelas/" . $id_kelas) ?>">Batal</a>
                  <button type="submit" class="btn btn-primary float-right" style="margin-top:10px">Simpan</button>
                </form>
              </div>
            </div>
          </div>
          <!-- /.card-body -->
        </div>
        <!-- /.card -->
      </div>
    </div>
    <!-- /.row -->
  </section>
  <!-- /.content -->
</div>
<!-- /.content-wrapper -->

<div class="modal fade" id="modal-tambah-materi">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title">Tambah Materi</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <form action="<?php echo base_url() ?>Kelas/tambah_materi" role="form" method="post">
        <div class="modal-body">
          <div class="form-group">
            <label>Judul Materi</label>
            <input type="text" class="form-control" name="judul_materi" required>
            <input type="text" class="form-control" name="id_kelas" value="<?php echo $this->uri->segment(3) ?>" required hidden>
          </div>
          <div class="form-group">
            <label>Tanggal Materi</label>
            <input type="date" class="form-control" name="tgl_materi" required>
          </div>
          <div class="form-group">
            <label class="text-black" for="nama">Jenis</label> <br>
            <div class="custom-control custom-radio custom-control-inline">
              <input type="radio" checked id="rb_materi" name="jenis_materi" value="Materi" class="custom-control-input">
              <label class="custom-control-label" for="rb_materi">Materi</label>
            </div>
            <div class="custom-control custom-radio custom-control-inline">
              <input type="radio" id="rb_tugas" name="jenis_materi" value="Tugas" class="custom-control-input">
              <label class="custom-control-label" for="rb_tugas">Tugas</label>
            </div>
          </div>
          <div class="form-group">
            <label>Deskripsi</label>
            <div class="mb-3">
              <textarea class="textarea" name="deskripsi" placeholder="Place some text here" style="width: 100%; height: 300px; font-size: 14px; line-height: 30px; border: 1px solid #dddddd; padding: 10px;"></textarea>
            </div>
          </div>
        </div>
        <div class="modal-footer justify-content-between">
          <button type="button" class="btn btn-default" data-dismiss="modal">Tutup</button>
          <button type="submit" class="btn btn-primary">Simpan</button>
        </div>
      </form>
    </div>
    <!-- /.modal-content -->
  </div>
  <!-- /.modal-dialog -->
</div>
<!-- /.modal -->

<div class="modal fade" id="modal-edit-materi">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title">Edit Materi</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <form action="<?php echo base_url() ?>" role="form" method="post">
        <div class="modal-body">
          <div class="form-group">
            <label>Judul Materi</label>
            <input type="text" class="form-control" id="judul_materi" name="judul_materi" required>
            <input type="text" class="form-control" name="id_kelas" value="<?php echo $this->uri->segment(3) ?>" required hidden>
            <input type="text" class="form-control" id="id_materi" name="id_materi" required hidden>
          </div>
          <div class="form-group">
            <label>Tanggal Materi</label>
            <input type="date" class="form-control" id="tgl_materi" name="tgl_materi" required>
          </div>
          <div class="form-group">
            <label class="text-black" for="nama">Jenis</label> <br>
            <div class="custom-control custom-radio custom-control-inline">
              <input type="radio" checked id="rb_materi_1" name="jenis_materi" value="Materi" class="custom-control-input">
              <label class="custom-control-label" for="rb_materi_1">Materi</label>
            </div>
            <div class="custom-control custom-radio custom-control-inline">
              <input type="radio" id="rb_tugas_1" name="jenis_materi" value="Tugas" class="custom-control-input">
              <label class="custom-control-label" for="rb_tugas_1">Tugas</label>
            </div>
          </div>
          <div class="form-group">
            <label>Deskripsi</label>
            <div class="mb-3">
              <textarea id="deskripsi" class="textarea" name="deskripsi" placeholder="Place some text here" style="width: 100%; height: 300px; font-size: 14px; line-height: 30px; border: 1px solid #dddddd; padding: 10px;"></textarea>
            </div>
          </div>
        </div>
        <div class="modal-footer justify-content-between">
          <button type="button" class="btn btn-default" data-dismiss="modal">Tutup</button>
          <button type="submit" class="btn btn-primary">Simpan</button>
        </div>
      </form>
    </div>
    <!-- /.modal-content -->
  </div>
  <!-- /.modal-dialog -->
</div>
<!-- /.modal -->

<div class="modal fade" id="modal-tambah-siswa">
  <div class="modal-dialog modal-sm">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title">Tambah Siswa</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <form action="<?php echo base_url() ?>Kelas/tambah_siswa_kelas" role="form" method="post">
        <div class="modal-body">
          <div class="form-group">
            <label>Siswa</label>
            <input type="text" class="form-control" name="id_kelas" value="<?php echo $this->uri->segment(3) ?>" required hidden>
            <select class="form-control select2" style="width: 100%;" name="id_siswa">
              <?php
              $no = 1;
              foreach ($daftar_siswa as $u) { ?>
                <option value="<?php echo $u->id ?>"><?php echo $u->nama ?></option>
              <?php } ?>
            </select>
          </div>
        </div>
        <div class="modal-footer justify-content-between">
          <button type="button" class="btn btn-default" data-dismiss="modal">Tutup</button>
          <button type="submit" class="btn btn-primary">Simpan</button>
        </div>
      </form>
    </div>
    <!-- /.modal-content -->
  </div>
  <!-- /.modal-dialog -->
</div>
<!-- /.modal -->