<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1>Detail Kelas</h1>
        </div>
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="<?php echo base_url() ?>">Home</a></li>
            <li class="breadcrumb-item"><a href="<?php echo base_url("Kelas") ?>">Kelas</a></li>
            <li class="breadcrumb-item active">Detail Kelas</li>
          </ol>
        </div>
      </div>
    </div><!-- /.container-fluid -->
  </section>

  <!-- Main content -->
  <section class="content">
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-3">

          <!-- About Me Box -->
          <div class="card card-primary">
            <div class="card-header">
              <h3 class="card-title">Tentang Kelas</h3>
            </div>
            <!-- /.card-header -->
            <div class="card-body">
              <strong><i class="fas fa-book mr-1"></i> Judul</strong>

              <p class="text-muted h3">
                <?php echo $detail_kelas['judul'] ?>
              </p>

              <hr>

              <strong><i class="fas fa-map-marker-alt mr-1"></i> Kode Kelas</strong>

              <p class="text-muted h3"><?php echo $detail_kelas['kode_kelas'] ?></p>

              <hr>

              <strong><i class="fas fa-pencil-alt mr-1"></i> Guru</strong>

              <p class="text-muted h3"><?php echo $detail_kelas['nama_guru'] ?></p>

              <hr>
            </div>
            <!-- /.card-body -->
          </div>
          <!-- /.card -->
        </div>
        <!-- /.col -->
        <div class="col-md-9">
          <div class="card">
            <div class="card-header p-2">
              <ul class="nav nav-pills">
                <li class="nav-item"><a class="nav-link active" href="#materi" data-toggle="tab">Materi</a></li>
                <li class="nav-item"><a class="nav-link" href="#siswa" data-toggle="tab">Siswa</a></li>
              </ul>
            </div><!-- /.card-header -->
            <div class="card-body">
              <div class="tab-content">
                <div class="active tab-pane" id="materi">
                  <div class="row">
                    <h3 class="col-lg-6 col-md-6 col-sm-6 col-xs-12">Materi</h3>
                    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                      <button class="btn btn-primary float-right" data-toggle="modal" data-target="#modal-tambah-materi">Tambah Materi</button>
                    </div>
                    <div class="col-md-12">
                      <?php
                      $no = 1;
                      foreach ($daftar_materi as $u) { ?>
                        <div class="card card-outline card-primary collapsed-card">
                          <div class="card-header">
                            <h3 class="card-title"><strong><?php echo $u->judul_materi ?></strong></h3>

                            <div class="card-tools">
                              <button type="button" class="btn btn-tool" data-card-widget="collapse"><i class="fas fa-plus"></i> </button>
                              <a type="button" class="btn btn-tool" href="<?php echo base_url() . 'Kelas/detail_materi_edit/' . $u->id . '/' . $this->uri->segment(3) ?>"><i class="fas fa-edit"></i> </a>
                              <a type="button" class="btn btn-tool" onclick="javascript: return confirm('Apakah Anda yakin ingin hapus kelas ini?')" href="<?php echo base_url() . 'Kelas/hapus_materi/' . $u->id . '/' . $this->uri->segment(3) ?>"><i class="fas fa-trash"></i> </a>
                            </div>
                            <!-- /.card-tools -->
                          </div>
                          <!-- /.card-header -->
                          <div class="card-body">
                            <dl>
                              <dt>Tanggal Materi</dt>
                              <dd><?php echo $u->tgl_materi ?></dd>
                              <dt>Jenis Materi</dt>
                              <dd><?php echo $u->jenis_materi ?></dd>
                              <dt>Materi</dt>
                              <dd>
                                <div class="callout callout-info">
                                  <?php echo $u->deskripsi ?>
                                </div>
                              </dd>
                              <?php if ($u->jenis_materi === "Tugas") { ?>
                                <dt>Daftar Tugas</dt>
                                <dd><button type="submit" class="btn btn-success">Lihat</button></dd>
                              <?php } ?>
                            </dl>
                          </div>
                          <!-- /.card-body -->
                        </div>
                      <?php } ?>
                    </div>
                  </div>
                </div>
                <!-- /.tab-pane -->
                <div class="tab-pane" id="siswa">
                  <div class="row">
                    <h3 class="col-lg-6 col-md-6 col-sm-6 col-xs-12">Daftar Siswa</h3>
                    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                      <button class="btn btn-primary float-right" data-toggle="modal" data-target="#modal-tambah-siswa">Tambah Siswa</button>
                    </div>
                    <div class="col-md-12">
                      <table class="table table-bordered table-striped example3">
                        <thead>
                          <tr>
                            <th>NIS</th>
                            <th>Nama</th>
                            <th>Tanggal Gabung</th>
                          </tr>
                        </thead>
                        <tbody>
                          <?php
                          $no = 1;
                          foreach ($daftar_siswa_kelas as $u) { ?>
                            <tr>
                              <td class="text-center"><?php echo $u->nis ?></td>
                              <td class="text-center"><?php echo $u->nama ?></td>
                              <td class="text-center"><?php echo $u->tgl_gabung ?></td>
                            </tr>
                          <?php } ?>
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
                <!-- /.tab-pane -->
              </div>
              <!-- /.tab-content -->
            </div><!-- /.card-body -->
          </div>
          <!-- /.nav-tabs-custom -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </div><!-- /.container-fluid -->
  </section>
  <!-- /.content -->
</div>
<!-- /.content-wrapper -->

<div class="modal fade" id="modal-tambah-materi">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title">Tambah Materi</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <form action="<?php echo base_url() ?>Kelas/tambah_materi" role="form" method="post">
        <div class="modal-body">
          <div class="form-group">
            <label>Judul Materi</label>
            <input type="text" class="form-control" name="judul_materi" required>
            <input type="text" class="form-control" name="id_kelas" value="<?php echo $this->uri->segment(3) ?>" required hidden>
          </div>
          <div class="form-group">
            <label>Tanggal Materi</label>
            <input type="date" class="form-control" name="tgl_materi" required>
          </div>
          <div class="form-group">
            <label class="text-black" for="nama">Jenis</label> <br>
            <div class="custom-control custom-radio custom-control-inline">
              <input type="radio" checked id="rb_materi" name="jenis_materi" value="Materi" class="custom-control-input">
              <label class="custom-control-label" for="rb_materi">Materi</label>
            </div>
            <div class="custom-control custom-radio custom-control-inline">
              <input type="radio" id="rb_tugas" name="jenis_materi" value="Tugas" class="custom-control-input">
              <label class="custom-control-label" for="rb_tugas">Tugas</label>
            </div>
          </div>
          <div class="form-group">
            <label>Deskripsi</label>
            <div class="mb-3">
              <textarea class="textarea" name="deskripsi" placeholder="Place some text here" style="width: 100%; height: 300px; font-size: 14px; line-height: 30px; border: 1px solid #dddddd; padding: 10px;"></textarea>
            </div>
          </div>
        </div>
        <div class="modal-footer justify-content-between">
          <button type="button" class="btn btn-default" data-dismiss="modal">Tutup</button>
          <button type="submit" class="btn btn-primary">Simpan</button>
        </div>
      </form>
    </div>
    <!-- /.modal-content -->
  </div>
  <!-- /.modal-dialog -->
</div>
<!-- /.modal -->

<div class="modal fade" id="modal-edit-materi">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title">Edit Materi</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <form action="<?php echo base_url() ?>Kelas/edit_materi" role="form" method="post">
        <div class="modal-body">
          <div class="form-group">
            <label>Judul Materi</label>
            <input type="text" class="form-control" id="judul_materi" name="judul_materi" required>
            <input type="text" class="form-control" name="id_kelas" value="<?php echo $this->uri->segment(3) ?>" required hidden>
            <input type="text" class="form-control" id="id_materi" name="id_materi" required hidden>
          </div>
          <div class="form-group">
            <label>Tanggal Materi</label>
            <input type="date" class="form-control" id="tgl_materi" name="tgl_materi" required>
          </div>
          <div class="form-group">
            <label class="text-black" for="nama">Jenis</label> <br>
            <div class="custom-control custom-radio custom-control-inline">
              <input type="radio" checked id="rb_materi_1" name="jenis_materi" value="Materi" class="custom-control-input">
              <label class="custom-control-label" for="rb_materi_1">Materi</label>
            </div>
            <div class="custom-control custom-radio custom-control-inline">
              <input type="radio" id="rb_tugas_1" name="jenis_materi" value="Tugas" class="custom-control-input">
              <label class="custom-control-label" for="rb_tugas_1">Tugas</label>
            </div>
          </div>
          <div class="form-group">
            <label>Deskripsi</label>
            <div class="mb-3">
              <textarea id="deskripsi" class="textarea" name="deskripsi" placeholder="Place some text here" style="width: 100%; height: 300px; font-size: 14px; line-height: 30px; border: 1px solid #dddddd; padding: 10px;"></textarea>
            </div>
          </div>
        </div>
        <div class="modal-footer justify-content-between">
          <button type="button" class="btn btn-default" data-dismiss="modal">Tutup</button>
          <button type="submit" class="btn btn-primary">Simpan</button>
        </div>
      </form>
    </div>
    <!-- /.modal-content -->
  </div>
  <!-- /.modal-dialog -->
</div>
<!-- /.modal -->

<div class="modal fade" id="modal-tambah-siswa">
  <div class="modal-dialog modal-sm">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title">Tambah Siswa</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <form action="<?php echo base_url() ?>Kelas/tambah_siswa_kelas" role="form" method="post">
        <div class="modal-body">
          <div class="form-group">
            <label>Siswa</label>
            <input type="text" class="form-control" name="id_kelas" value="<?php echo $this->uri->segment(3) ?>" required hidden>
            <select class="form-control select2" style="width: 100%;" name="id_siswa">
              <?php
              $no = 1;
              foreach ($daftar_siswa as $u) { ?>
                <option value="<?php echo $u->id ?>"><?php echo $u->nama ?></option>
              <?php } ?>
            </select>
          </div>
        </div>
        <div class="modal-footer justify-content-between">
          <button type="button" class="btn btn-default" data-dismiss="modal">Tutup</button>
          <button type="submit" class="btn btn-primary">Simpan</button>
        </div>
      </form>
    </div>
    <!-- /.modal-content -->
  </div>
  <!-- /.modal-dialog -->
</div>
<!-- /.modal -->