<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1>Guru</h1>
        </div>
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="<?php echo base_url() ?>">Home</a></li>
            <li class="breadcrumb-item active">Guru</li>
          </ol>
        </div>
      </div>
    </div><!-- /.container-fluid -->
  </section>

  <!-- Main content -->
  <section class="content">
    <div class="row">
      <div class="col-lg-12">
        <div class="card">
          <div class="card-header">
            <div class="row">
              <h3 class="col-lg-6 col-md-6 col-sm-6 col-xs-12">Guru</h3>
              <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                <button class="btn btn-primary float-right" data-toggle="modal" data-target="#modal-tambah-guru">Tambah</button>
              </div>
            </div>
          </div>
          <div class="card-body table-responsive">
            <table class="table table-bordered table-striped example3">
              <thead>
                <tr>
                  <th>NIG</th>
                  <th>Nama</th>
                  <th>Tempat Lahir</th>
                  <th>Tanggal Lahir</th>
                  <th>Jenis Kelamin</th>
                  <th>Alamat</th>
                  <th>Aksi</th>
                </tr>
              </thead>
              <tbody>
                <?php
                $no = 1;
                foreach ($daftar_guru as $u) { ?>
                  <tr>
                    <td class="text-center"><?php echo $u->nig ?></td>
                    <td class="text-center"><?php echo $u->nama ?></td>
                    <td class="text-center"><?php echo $u->tempat_lahir ?></td>
                    <td class="text-center"><?php echo $u->tanggal_lahir ?></td>
                    <td class="text-center"><?php echo $u->jns_kelamin ?></td>
                    <td class="text-center"><?php echo $u->alamat ?></td>
                    <td class="text-center">
                      <a class="btn btn-sm btn-warning" data-toggle="modal" data-target=#modal-edit-guru onClick="editguru('<?php echo $u->id ?>', '<?php echo $u->id_user ?>', '<?php echo $u->nig ?>', '<?php echo $u->nama ?>', '<?php echo $u->tempat_lahir ?>', '<?php echo $u->tanggal_lahir ?>', '<?php echo $u->jenis_kelamin ?>', '<?php echo $u->alamat ?>')" href="#"><i class="fa fa-pencil-alt"></i></a>
                      <a class="btn btn-sm btn-danger" onclick="javascript: return confirm('Apakah Anda yakin ingin hapus data ini?')" href="<?php echo base_url() . 'Guru/hapus_guru/' . $u->id ?>"><i class="fa fa-trash"></i></a>
                    </td>
                  </tr>
                <?php } ?>
              </tbody>
            </table>
          </div>
          <!-- /.card-body -->
        </div>
        <!-- /.card -->
      </div>
    </div>
    <!-- /.row -->
  </section>
  <!-- /.content -->
</div>
<!-- /.content-wrapper -->

<script>
  function editguru(id, id_user, nig, nama, tempat_lahir, tanggal_lahir, jenis_kelamin, alamat) {
    document.getElementById('id_guru').value = id;
    document.getElementById('id_user').value = id_user;
    document.getElementById('nig').value = nig;
    document.getElementById('nama_lengkap').value = nama;
    document.getElementById('tempat_lahir').value = tempat_lahir;
    document.getElementById('tanggal_lahir').value = tanggal_lahir;
    document.getElementById('alamat').value = alamat;
    if (jenis_kelamin === "L") {
      document.getElementById('rb_laki').checked = true;
    } else {
      document.getElementById('rb_perempuan').checked = true;
    }
  }
</script>

<div class="modal fade" id="modal-tambah-guru">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title">Tambah Guru</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <form action="<?php echo base_url() ?>Guru/tambah_guru" role="form" method="post">
        <div class="modal-body">
          <div class="form-group">
            <label>Nomor Induk Guru</label>
            <input type="text" class="form-control" name="nig" required>
          </div>
          <div class="form-group">
            <label>Nama Lengkap</label>
            <input type="text" class="form-control" name="nama" required>
          </div>
          <div class="form-group">
            <label>Tempat Lahir</label>
            <input type="text" class="form-control" name="tempat_lahir" required>
          </div>
          <div class="form-group">
            <label>Tanggal Lahir</label>
            <input type="date" class="form-control" name="tanggal_lahir" required>
          </div>
          <div class="form-group">
            <label class="text-black" for="nama">Jenis Kelamin</label> <br>
            <div class="custom-control custom-radio custom-control-inline">
              <input type="radio" checked id="customRadio4" name="jenis_kelamin" value="L" class="custom-control-input">
              <label class="custom-control-label" for="customRadio4">Laki - Laki</label>
            </div>
            <div class="custom-control custom-radio custom-control-inline">
              <input type="radio" id="customRadio5" name="jenis_kelamin" value="P" class="custom-control-input">
              <label class="custom-control-label" for="customRadio5">Perempuan</label>
            </div>
          </div>
          <div class="form-group">
            <label>Alamat</label>
            <input type="text" class="form-control" name="alamat" required>
          </div>
          <div class="form-group">
            <label>Password</label>
            <input type="password" class="form-control" name="password" required>
          </div>
        </div>
        <div class="modal-footer justify-content-between">
          <button type="button" class="btn btn-default" data-dismiss="modal">Tutup</button>
          <button type="submit" class="btn btn-primary">Simpan</button>
        </div>
      </form>
    </div>
    <!-- /.modal-content -->
  </div>
  <!-- /.modal-dialog -->
</div>
<!-- /.modal -->

<div class="modal fade" id="modal-edit-guru">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title">Edit Guru</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <form action="<?php echo base_url() ?>Guru/edit_guru" role="form" method="post">
        <div class="modal-body">
          <div class="form-group">
            <label>Nomor Induk Guru</label>
            <input type="text" id="nig" class="form-control" name="nig" required>
            <input type="text" id="id_guru" class="form-control" name="id_guru" required hidden>
            <input type="text" id="id_user" class="form-control" name="id_user" required hidden>
          </div>
          <div class="form-group">
            <label>Nama Lengkap</label>
            <input type="text" id="nama_lengkap" class="form-control" name="nama" required>
          </div>
          <div class="form-group">
            <label>Tempat Lahir</label>
            <input type="text" id="tempat_lahir" class="form-control" name="tempat_lahir" required>
          </div>
          <div class="form-group">
            <label>Tanggal Lahir</label>
            <input type="date" id="tanggal_lahir" class="form-control" name="tanggal_lahir" required>
          </div>
          <div class="form-group">
            <label class="text-black" for="nama">Jenis Kelamin</label> <br>
            <div class="custom-control custom-radio custom-control-inline">
              <input type="radio" checked id="rb_laki" name="jenis_kelamin" value="L" class="custom-control-input">
              <label class="custom-control-label" for="rb_laki">Laki - Laki</label>
            </div>
            <div class="custom-control custom-radio custom-control-inline">
              <input type="radio" id="rb_perempuan" name="jenis_kelamin" value="P" class="custom-control-input">
              <label class="custom-control-label" for="rb_perempuan">Perempuan</label>
            </div>
          </div>
          <div class="form-group">
            <label>Alamat</label>
            <input type="text" id="alamat" class="form-control" name="alamat" required>
          </div>
          <div class="form-group">
            <label>Password</label>
            <input type="password" class="form-control" name="password">
          </div>
        </div>
        <div class="modal-footer justify-content-between">
          <button type="button" class="btn btn-default" data-dismiss="modal">Tutup</button>
          <button type="submit" class="btn btn-primary">Simpan</button>
        </div>
      </form>
    </div>
    <!-- /.modal-content -->
  </div>
  <!-- /.modal-dialog -->
</div>
<!-- /.modal -->