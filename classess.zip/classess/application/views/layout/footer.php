<!-- jQuery -->
<script src="<?php echo base_url() ?>asset/plugins/jquery/jquery.min.js"></script>
<!-- jQuery UI 1.11.4 -->
<script src="<?php echo base_url() ?>asset/plugins/jquery-ui/jquery-ui.min.js"></script>
<!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
<script>
  $.widget.bridge('uibutton', $.ui.button)
</script>
<!-- Bootstrap 4 -->
<script src="<?php echo base_url() ?>asset/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- ChartJS -->
<script src="<?php echo base_url() ?>asset/plugins/chart.js/Chart.min.js"></script>
<!-- overlayScrollbars -->
<script src="<?php echo base_url() ?>asset/plugins/overlayScrollbars/js/jquery.overlayScrollbars.min.js"></script>
<!-- AdminLTE App -->
<script src="<?php echo base_url() ?>asset/dist/js/adminlte.js"></script>
<!-- <script src="https://cdn.jsdelivr.net/npm/admin-lte@3.1/dist/js/adminlte.min.js"></script> -->
<!-- DataTables -->
<!-- Select2 -->
<script src="<?php echo base_url() ?>asset/plugins/select2/js/select2.full.min.js"></script>
<!-- Toastr -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js" integrity="sha512-VEd+nq25CkR676O+pLBnDW09R7VQX9Mdiij052gVCp5yVH3jGtH70Ho/UUv4mJDsEdTvqRCFZg0NKGiojGnUCw==" crossorigin="anonymous"></script>
<script src="<?php echo base_url() ?>asset/plugins/datatables/jquery.dataTables.js"></script>
<script src="<?php echo base_url() ?>asset/plugins/datatables-bs4/js/dataTables.bootstrap4.js"></script>
<!-- Summernote -->
<!-- <script src="<?php echo base_url() ?>asset/plugins/summernote/summernote-bs4.min.js"></script> -->
<script src="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote-bs4.min.js"></script>
<script>
  $(function() {
    $('.select2').select2({
      theme: 'bootstrap4'
    });

    // Summernote
    $('.textarea').summernote();

    <?php
    $this->load->helper('form');
    $error = $this->session->flashdata('error');
    if ($error) {
    ?>
      toastr.error('<?php echo $error; ?>');
    <?php }
    $success = $this->session->flashdata('success');
    if ($success) {
    ?>
      toastr.success('<?php echo $success; ?>');
    <?php } ?>

    $(".example3").DataTable({});
    $(".example1").DataTable({
      "paging": false,
      "lengthChange": false,
      "searching": false,
      "ordering": false,
      "info": false,
      "autoWidth": false,
      "aaSorting": [],
    });
    $('.example2').DataTable({
      "paging": false,
      "lengthChange": false,
      "searching": false,
      "ordering": true,
      "info": true,
      "autoWidth": false,
      "aaSorting": [],
      "bInfo": false
    });    

  });
</script>
</body>

</html>