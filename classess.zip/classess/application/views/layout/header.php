<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>CLASSES</title>
    <!-- Tell the browser to be responsive to screen width -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="<?php echo base_url() ?>asset/plugins/fontawesome-free/css/all.min.css">
    <!-- Ionicons -->
    <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
    <!-- DataTables -->
    <link rel="stylesheet" href="<?php echo base_url() ?>asset/plugins/datatables-bs4/css/dataTables.bootstrap4.css">
    <!-- Theme style -->
    <link rel="stylesheet" href="<?php echo base_url() ?>asset/dist/css/adminlte.min.css">
    <!-- <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/admin-lte@3.1/dist/css/adminlte.min.css"> -->
    <!-- Toastr -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.css" integrity="sha512-3pIirOrwegjM6erE5gPSwkUzO+3cTjpnV9lexlNZqvupR64iZBnOOTiiLPb9M36zpMScbmUNIcHUqKD47M719g==" crossorigin="anonymous" />
    <!-- overlayScrollbars -->
    <link rel="stylesheet" href="<?php echo base_url() ?>asset/plugins/overlayScrollbars/css/OverlayScrollbars.min.css">
    <!-- Google Font: Source Sans Pro -->
    <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
    <!-- Select2 -->
    <link rel="stylesheet" href="<?php echo base_url() ?>asset/plugins/select2/css/select2.min.css">
    <link rel="stylesheet" href="<?php echo base_url() ?>asset/plugins/select2-bootstrap4-theme/select2-bootstrap4.min.css">
    <!-- summernote -->
    <!-- <link rel="stylesheet" href="<?php echo base_url() ?>asset/plugins/summernote/summernote-bs4.css"> -->
    <link href="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote-bs4.min.css" rel="stylesheet">
</head>

<body class="hold-transition sidebar-mini layout-fixed">
    <div class="wrapper">

        <!-- Navbar -->
        <nav class="main-header navbar navbar-expand navbar-white navbar-light">
            <!-- Left navbar links -->
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link" data-widget="pushmenu" href="#"><i class="fas fa-bars"></i></a>
                </li>
            </ul>

            <!-- Right navbar links -->
            <ul class="navbar-nav ml-auto">
                <li class="nav-item dropdown user user-menu">
                    <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown">
                        <img src="<?php echo base_url() ?>asset/dist/img/avatar.png" class="user-image img-circle elevation-2 alt=" User Image">
                        <span class="hidden-xs"><?php echo $this->session->userdata('nama_user') ?></span>
                    </a>
                    <ul class="dropdown-menu dropdown-menu-lg dropdown-menu-right">
                        <!-- User image -->
                        <li class="user-header bg-primary">
                            <img src="<?php echo base_url() ?>asset/dist/img/avatar.png" class="img-circle elevation-2" alt="User Image">
                            <p>
                                <?php echo $this->session->userdata('nama_user') ?>
                            </p>
                        </li>
                        <!-- Menu Footer-->
                        <li class="user-footer">
                            <div class="col-12">
                                <a href="<?php echo base_url() ?>logout" class="btn btn-danger btn-flat float-right">Sign out</a>
                            </div>
                        </li>
                    </ul>
                </li>
            </ul>
        </nav>
        <!-- /.navbar -->

        <!-- Main Sidebar Container -->
        <aside class="main-sidebar sidebar-dark-primary elevation-4">
            <!-- Brand Logo -->
            <a href="<?php echo base_url() ?>" class="brand-link">
                <img src="<?php echo base_url() ?>asset/dist/img/AdminLTELogo.png" alt="AdminLTE Logo" class="brand-image img-circle elevation-3" style="opacity: .8">
                <span class="brand-text font-weight-light">Classes</span>
            </a>

            <!-- Sidebar -->
            <div class="sidebar">
                <!-- Sidebar Menu -->
                <nav class="mt-2">
                    <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
                        <li class="nav-item">
                            <a href="<?php echo base_url() ?>" <?php if ($this->uri->segment(1) == "") {
                                                                    echo 'class="active nav-link"';
                                                                } else {
                                                                    echo 'class="nav-link"';
                                                                } ?>>
                                <i class="nav-icon fas fa-tachometer-alt"></i>
                                <p> Dashboard </p>
                            </a>
                        </li>
                        <?php if ($this->session->userdata('role') === "Admin") { ?>
                            <li class="nav-item">
                                <a href="<?php echo base_url() ?>Siswa" <?php if ($this->uri->segment(1) == "Siswa") {
                                                                            echo 'class="active nav-link"';
                                                                        } else {
                                                                            echo 'class="nav-link"';
                                                                        } ?>>
                                    <i class="nav-icon fas fa-th"></i>
                                    <p> Siswa </p>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="<?php echo base_url() ?>Guru" <?php if ($this->uri->segment(1) == "Guru") {
                                                                            echo 'class="active nav-link"';
                                                                        } else {
                                                                            echo 'class="nav-link"';
                                                                        } ?>>
                                    <i class="nav-icon fas fa-th"></i>
                                    <p> Guru </p>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="<?php echo base_url() ?>User" <?php if ($this->uri->segment(1) == "User") {
                                                                            echo 'class="active nav-link"';
                                                                        } else {
                                                                            echo 'class="nav-link"';
                                                                        } ?>>
                                    <i class="nav-icon fas fa-th"></i>
                                    <p> User </p>
                                </a>
                            </li>
                        <?php } ?>
                        <?php if ($this->session->userdata('role') === "Admin" || $this->session->userdata('role') === "Guru") { ?>
                            <li class="nav-item">
                                <a href="<?php echo base_url() ?>Kelas" <?php if ($this->uri->segment(1) == "Kelas") {
                                                                            echo 'class="active nav-link"';
                                                                        } else {
                                                                            echo 'class="nav-link"';
                                                                        } ?>>
                                    <i class="nav-icon fas fa-th"></i>
                                    <p> Kelas </p>
                                </a>
                            </li>
                        <?php } ?>
                        <?php if ($this->session->userdata('role') === "Siswa") { ?>
                            <li class="nav-item">
                                <a href="<?php echo base_url() ?>kelas_saya" <?php if ($this->uri->segment(1) == "kelas_saya") {
                                                                            echo 'class="active nav-link"';
                                                                        } else {
                                                                            echo 'class="nav-link"';
                                                                        } ?>>
                                    <i class="nav-icon fas fa-th"></i>
                                    <p> Kelas Saya </p>
                                </a>
                            </li>
                        <?php } ?>
                        <?php if ($this->session->userdata('role') === "Admin" || $this->session->userdata('role') === "Siswa") { ?>
                            <li class="nav-item">
                                <a href="<?php echo base_url() ?>tugas" <?php if ($this->uri->segment(1) == "tugas") {
                                                                            echo 'class="active nav-link"';
                                                                        } else {
                                                                            echo 'class="nav-link"';
                                                                        } ?>>
                                    <i class="nav-icon fas fa-th"></i>
                                    <p> Tugas </p>
                                </a>
                            </li>
                        <?php } ?>                        
                    </ul>
                </nav>
                <!-- /.sidebar-menu -->
            </div>
            <!-- /.sidebar -->
        </aside>