<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1>User</h1>
        </div>
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="<?php echo base_url() ?>">Home</a></li>
            <li class="breadcrumb-item active">User</li>
          </ol>
        </div>
      </div>
    </div><!-- /.container-fluid -->
  </section>

  <!-- Main content -->
  <section class="content">
    <div class="row">
      <div class="col-lg-12">
        <div class="card">
          <div class="card-header">
            <div class="row">
              <h3 class="col-lg-6 col-md-6 col-sm-6 col-xs-12">User</h3>
              <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                <button class="btn btn-primary float-right" data-toggle="modal" data-target="#modal-tambah-user">Tambah</button>
              </div>
            </div>
          </div>
          <div class="card-body table-responsive">
            <table class="table table-bordered table-striped example3">
              <thead>
                <tr>
                  <th>No</th>
                  <th>Nama</th>
                  <th>Username</th>
                  <th>Role</th>
                  <th>Aksi</th>
                </tr>
              </thead>
              <tbody>
                <?php
                $no = 1;
                foreach ($daftar_user as $u) { ?>
                  <tr>
                    <td class="text-center"><?php echo $no++ ?></td>
                    <td class="text-center"><?php echo $u->nama ?></td>
                    <td class="text-center"><?php echo $u->username ?></td>
                    <td class="text-center"><?php echo $u->role ?></td>
                    <td class="text-center">
                      <a class="btn btn-sm btn-warning" data-toggle="modal" data-target=#modal-edit-user onClick="edituser('<?php echo $u->id ?>', '<?php echo $u->nama ?>', '<?php echo $u->username ?>', '<?php echo $u->role ?>')" href="#"><i class="fa fa-pencil-alt"></i></a>
                      <a class="btn btn-sm btn-danger" onclick="javascript: return confirm('Apakah Anda yakin ingin hapus data ini?')" href="<?php echo base_url() . 'User/hapus_user/' . $u->id ?>"><i class="fa fa-trash"></i></a>
                    </td>
                  </tr>
                <?php } ?>
              </tbody>
            </table>
          </div>
          <!-- /.card-body -->
        </div>
        <!-- /.card -->
      </div>
    </div>
    <!-- /.row -->
  </section>
  <!-- /.content -->
</div>
<!-- /.content-wrapper -->

<script>
  function edituser(id, nama, username, role) {
    document.getElementById('id_user').value = id;
    document.getElementById('nama_lengkap').value = nama;
    document.getElementById('username').value = username;
    if (role === "Admin") {
      document.getElementById('rb_admin').checked = true;
    } else if (role === "Guru") {
      document.getElementById('rb_guru').checked = true;
    } else if (role === "Siswa") {
      document.getElementById('rb_siswa').checked = true;
    }
  }
</script>

<div class="modal fade" id="modal-tambah-user">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title">Tambah User</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <form action="<?php echo base_url() ?>User/tambah_user" role="form" method="post">
        <div class="modal-body">
          <div class="form-group">
            <label>Nama Lengkap</label>
            <input type="text" class="form-control" name="nama" required>
          </div>
          <div class="form-group">
            <label>Username</label>
            <input type="text" class="form-control" name="username" required>
          </div>
          <div class="form-group">
            <label>Password</label>
            <input type="password" class="form-control" name="password" required>
          </div>
          <div class="form-group">
            <label class="text-black" for="nama">Role</label> <br>
            <div class="custom-control custom-radio custom-control-inline">
              <input type="radio" checked id="customRadio4" name="role" value="Admin" class="custom-control-input">
              <label class="custom-control-label" for="customRadio4">Admin</label>
            </div>
            <div class="custom-control custom-radio custom-control-inline">
              <input type="radio" id="customRadio5" name="role" value="Guru" class="custom-control-input">
              <label class="custom-control-label" for="customRadio5">Guru</label>
            </div>
            <div class="custom-control custom-radio custom-control-inline">
              <input type="radio" id="customRadio6" name="role" value="Siswa" class="custom-control-input">
              <label class="custom-control-label" for="customRadio6">Siswa</label>
            </div>
          </div>
        </div>
        <div class="modal-footer justify-content-between">
          <button type="button" class="btn btn-default" data-dismiss="modal">Tutup</button>
          <button type="submit" class="btn btn-primary">Simpan</button>
        </div>
      </form>
    </div>
    <!-- /.modal-content -->
  </div>
  <!-- /.modal-dialog -->
</div>
<!-- /.modal -->

<div class="modal fade" id="modal-edit-user">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title">Edit User</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <form action="<?php echo base_url() ?>User/edit_user" role="form" method="post">
        <div class="modal-body">
          <div class="form-group">
            <label>Nama Lengkap</label>
            <input type="text" class="form-control" id="nama_lengkap" name="nama" required>
            <input type="text" class="form-control" id="id_user" name="id_user" required hidden>
          </div>
          <div class="form-group">
            <label>Username</label>
            <input type="text" class="form-control" id="username" name="username" required>
          </div>
          <div class="form-group">
            <label>Password</label>
            <input type="password" class="form-control" name="password">
          </div>
          <div class="form-group">
            <label class="text-black" for="nama">Role</label> <br>
            <div class="custom-control custom-radio custom-control-inline">
              <input type="radio" checked id="rb_admin" name="role" value="Admin" class="custom-control-input">
              <label class="custom-control-label" for="rb_admin">Admin</label>
            </div>
            <div class="custom-control custom-radio custom-control-inline">
              <input type="radio" id="rb_guru" name="role" value="Guru" class="custom-control-input">
              <label class="custom-control-label" for="rb_guru">Guru</label>
            </div>
            <div class="custom-control custom-radio custom-control-inline">
              <input type="radio" id="rb_siswa" name="role" value="Siswa" class="custom-control-input">
              <label class="custom-control-label" for="rb_siswa">Siswa</label>
            </div>
          </div>
          <div class="modal-footer justify-content-between">
            <button type="button" class="btn btn-default" data-dismiss="modal">Tutup</button>
            <button type="submit" class="btn btn-primary">Simpan</button>
          </div>
      </form>
    </div>
    <!-- /.modal-content -->
  </div>
  <!-- /.modal-dialog -->
</div>
<!-- /.modal -->