/*
 Navicat Premium Data Transfer

 Source Server         : locahost
 Source Server Type    : MySQL
 Source Server Version : 100411
 Source Host           : localhost:3306
 Source Schema         : classes

 Target Server Type    : MySQL
 Target Server Version : 100411
 File Encoding         : 65001

 Date: 06/03/2021 17:11:30
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for tbl_guru
-- ----------------------------
DROP TABLE IF EXISTS `tbl_guru`;
CREATE TABLE `tbl_guru`  (
  `id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `nig` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `nama` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `tempat_lahir` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `tanggal_lahir` date NULL DEFAULT NULL,
  `jenis_kelamin` enum('L','P') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `alamat` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `status` tinyint(255) NULL DEFAULT 1,
  `create_date` datetime(0) NULL DEFAULT NULL,
  `update_date` datetime(0) NULL DEFAULT NULL,
  `create_by` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `update_by` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of tbl_guru
-- ----------------------------
INSERT INTO `tbl_guru` VALUES ('460802a8-53a7-48ac-a102-41da41aea2d6', '1212', 'Testing Pemilik', 'Makassar', '1998-09-21', 'P', 'Jl. tinumbu no 8', 1, '0000-00-00 00:00:00', NULL, '1', NULL);
INSERT INTO `tbl_guru` VALUES ('effbeeeb-fd01-4ea1-a136-82afe0429112', '123', 'Jason pratama Sunarji', 'Makassar', '1998-09-21', 'P', 'apa saja', 1, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '1', '1');

-- ----------------------------
-- Table structure for tbl_kelas
-- ----------------------------
DROP TABLE IF EXISTS `tbl_kelas`;
CREATE TABLE `tbl_kelas`  (
  `id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `kode_kelas` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `judul` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `id_guru` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `tgl_mulai` date NULL DEFAULT NULL,
  `create_by` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `create_date` datetime(0) NULL DEFAULT NULL,
  `update_by` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `update_date` datetime(0) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of tbl_kelas
-- ----------------------------
INSERT INTO `tbl_kelas` VALUES ('193fe3a9-2dc2-4e04-ac06-cf573f1aa3ef', 'SzTFC', 'Algoritma Pemograman 2', '460802a8-53a7-48ac-a102-41da41aea2d6', '2021-03-21', '1', '2021-03-06 07:24:52', '4c3f017a-f8bc-4b55-9955-ee223ec29c10', '2021-03-06 07:28:03');
INSERT INTO `tbl_kelas` VALUES ('52dbf153-fb96-4bb8-8b6c-b2b1d61f81d0', 'zGyia', 'Algoritma Pemograman 1', 'effbeeeb-fd01-4ea1-a136-82afe0429112', '2021-03-06', '8fc995b5-e01d-431b-b25d-5c5241dfe7d7', '2021-03-06 09:45:20', NULL, NULL);
INSERT INTO `tbl_kelas` VALUES ('7368e00d-53ed-43c9-aafe-b01756be47f6', 'aWOJV', 'Digital Enterpriuner', NULL, '2021-01-21', '1', '2021-03-01 00:00:00', NULL, NULL);
INSERT INTO `tbl_kelas` VALUES ('90270c87-9e79-48fe-9387-87090dd84fec', '8318d', 'Kalkulus 1', 'effbeeeb-fd01-4ea1-a136-82afe0429112', '2021-03-01', '1', '2021-03-06 00:00:00', NULL, NULL);

-- ----------------------------
-- Table structure for tbl_kelas_siswa
-- ----------------------------
DROP TABLE IF EXISTS `tbl_kelas_siswa`;
CREATE TABLE `tbl_kelas_siswa`  (
  `id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `id_kelas` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `id_siswa` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `tgl_gabung` datetime(0) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of tbl_kelas_siswa
-- ----------------------------
INSERT INTO `tbl_kelas_siswa` VALUES ('77edee65-5bc4-4af7-8f8f-d4237b91f634', '90270c87-9e79-48fe-9387-87090dd84fec', '4fd63578-f1f3-4298-b15c-a62942c1a410', '2021-03-06 06:13:56');
INSERT INTO `tbl_kelas_siswa` VALUES ('9ac5bee4-f10d-46a6-889d-1f4e652b3bce', '52dbf153-fb96-4bb8-8b6c-b2b1d61f81d0', '4fd63578-f1f3-4298-b15c-a62942c1a410', '2021-03-06 09:51:02');
INSERT INTO `tbl_kelas_siswa` VALUES ('9bcef172-788a-4eeb-a82d-3db9db7c8866', '193fe3a9-2dc2-4e04-ac06-cf573f1aa3ef', '4fd63578-f1f3-4298-b15c-a62942c1a410', '2021-03-06 08:14:53');

-- ----------------------------
-- Table structure for tbl_materi
-- ----------------------------
DROP TABLE IF EXISTS `tbl_materi`;
CREATE TABLE `tbl_materi`  (
  `id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `id_kelas` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `judul_materi` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `tgl_materi` date NULL DEFAULT NULL,
  `jenis_materi` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `deskripsi` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL,
  `create_by` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `create_date` datetime(0) NULL DEFAULT NULL,
  `update_by` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `update_date` datetime(0) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of tbl_materi
-- ----------------------------
INSERT INTO `tbl_materi` VALUES ('4dc5d319-b845-4a37-bf51-ba9a44edb39d', '52dbf153-fb96-4bb8-8b6c-b2b1d61f81d0', 'Bab 2. Manfaat Algoritma', '2021-03-07', 'Tugas', '<p>ini harus dikumpulkan paling lambat minggu</p>', '8fc995b5-e01d-431b-b25d-5c5241dfe7d7', '2021-03-06 09:48:11', NULL, NULL);
INSERT INTO `tbl_materi` VALUES ('797376c2-4d7f-4c9e-9384-86eee7eae4c1', '193fe3a9-2dc2-4e04-ac06-cf573f1aa3ef', 'Bab 2. Manfaat Algoritma', '2021-03-02', 'Materi', '<p>Apa mo saja lah yah</p>', '4c3f017a-f8bc-4b55-9955-ee223ec29c10', '2021-03-06 08:28:01', NULL, NULL);
INSERT INTO `tbl_materi` VALUES ('b3dff194-739c-4f83-88e5-4dbb0ef4678b', '90270c87-9e79-48fe-9387-87090dd84fec', 'Bab 1. Apa itu kalkulus', '2021-03-02', 'Materi', '<p>APa saja yah testing aja bede</p>', '8fc995b5-e', '0000-00-00 00:00:00', NULL, NULL);
INSERT INTO `tbl_materi` VALUES ('b8a2da97-5317-4427-a24e-66eb3f8ef3f0', '52dbf153-fb96-4bb8-8b6c-b2b1d61f81d0', 'Bab 1. Pengertian Algoritma Pemograman', '2021-03-06', 'Materi', '<p>Testing aja lah yah</p><p>apa saja&nbsp;</p><p><b>Pengertian algoritma</b></p>', '8fc995b5-e01d-431b-b25d-5c5241dfe7d7', '2021-03-06 09:47:39', NULL, NULL);
INSERT INTO `tbl_materi` VALUES ('c6dff06c-1cd2-48e3-88ff-288089b3fcf1', '193fe3a9-2dc2-4e04-ac06-cf573f1aa3ef', 'Bab 1. Pengertian Algoritma Pemograman', '2021-01-21', 'Materi', '<p><span style=\"font-family: undefined;\">﻿</span><b>Pengertian Algoritma</b></p><p><span style=\"font-family: \"Source Sans Pro\";\">algoritma adalah sebua</span><span style=\"font-family: \"Segoe UI\";\">﻿</span><span style=\"font-family: \"Source Sans Pro\";\">h </span><span style=\"color: rgb(77, 81, 86); font-family: \"Source Sans Pro\"; font-size: 14px;\">Dalam matematika dan ilmu komputer, algoritme adalah prosedur langkah-demi-langkah untuk penghitungan. Algoritme digunakan untuk penghitungan, pemrosesan data, dan penalaran otomatis. Algoritme adalah metode efektif diekspresikan sebagai rangkaian terbatas dari instruksi-instruksi yang telah didefinisikan dengan baik</span><span style=\"color: rgb(77, 81, 86); font-family: arial, sans-serif; font-size: 14px;\"><span style=\"font-family: \"Source Sans Pro\";\"> </span><a class=\"ruhjFe NJLBac fl\" href=\"https://id.wikipedia.org/wiki/Algoritme\" data-ved=\"2ahUKEwiW66nbhpvvAhWKA3IKHUb_B2EQmhMwInoECCgQAg\" ping=\"/url?sa=t&source=web&rct=j&url=https://id.wikipedia.org/wiki/Algoritme&ved=2ahUKEwiW66nbhpvvAhWKA3IKHUb_B2EQmhMwInoECCgQAg\" style=\"color: rgb(26, 13, 171); -webkit-tap-highlight-color: rgba(0, 0, 0, 0.1); white-space: nowrap; outline: 0px;\"><span style=\"font-family: \"Source Sans Pro\";\">Wikipedia</span></a></span></p>', '4c3f017a-f8bc-4b55-9955-ee223ec29c10', '2021-03-06 07:37:12', '4c3f017a-f8bc-4b55-9955-ee223ec29c10', '2021-03-06 09:12:33');
INSERT INTO `tbl_materi` VALUES ('fa12dd22-e231-4710-94eb-ddaadc3c5649', '90270c87-9e79-48fe-9387-87090dd84fec', 'Bab 2. Apa itu kalkulus', '2021-01-03', 'Tugas', '<p><b>Bab 2</b></p><p>mengapa kita harus belajar kalkulus, untuk menguji pemahaman kita yaitu</p><ol><li>Kecerdasan</li><li>Logika</li><li>Ingin tahu</li><li>Penasaran</li><li>Tidak Masuk Akal</li></ol>', '8fc995b5-e', '2021-03-06 05:26:49', NULL, NULL);

-- ----------------------------
-- Table structure for tbl_siswa
-- ----------------------------
DROP TABLE IF EXISTS `tbl_siswa`;
CREATE TABLE `tbl_siswa`  (
  `id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `nis` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `nama` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `tempat_lahir` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `tanggal_lahir` date NULL DEFAULT NULL,
  `jenis_kelamin` enum('L','P') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `alamat` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `status` tinyint(255) NULL DEFAULT 1,
  `create_date` datetime(0) NULL DEFAULT NULL,
  `update_date` datetime(0) NULL DEFAULT NULL,
  `create_by` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `update_by` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of tbl_siswa
-- ----------------------------
INSERT INTO `tbl_siswa` VALUES ('4fd63578-f1f3-4298-b15c-a62942c1a410', '12345', 'Budi Saja', 'Makassar', '2000-01-21', 'P', 'Apa lah', 1, '0000-00-00 00:00:00', NULL, '1', NULL);
INSERT INTO `tbl_siswa` VALUES ('c73ddf0c-1f57-4d70-9beb-b439f7087490', '123123', 'Jason pratama 2', 'Makassar', '1998-09-21', 'P', 'APa saja', 1, '0000-00-00 00:00:00', '2021-03-27 00:00:00', '1', '1');

-- ----------------------------
-- Table structure for tbl_user
-- ----------------------------
DROP TABLE IF EXISTS `tbl_user`;
CREATE TABLE `tbl_user`  (
  `id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `nama` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `username` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `password` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `role` enum('Admin','Guru','Siswa') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `create_by` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `create_date` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `update_by` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `update_date` datetime(0) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of tbl_user
-- ----------------------------
INSERT INTO `tbl_user` VALUES ('4c3f017a-f8bc-4b55-9955-ee223ec29c10', 'Testing Pemilik', '1212', 'e10adc3949ba59abbe56e057f20f883e', 'Guru', '1', '2021-03-47', NULL, NULL);
INSERT INTO `tbl_user` VALUES ('787eba21-e887-4d60-a2f7-4fa293d66f37', 'Budi Prakarsa', '123', 'e10adc3949ba59abbe56e057f20f883e', 'Guru', '1', '2021-03-52', '1', '0000-00-00 00:00:00');
INSERT INTO `tbl_user` VALUES ('8fc995b5-e01d-431b-b25d-5c5241dfe7d7', 'anton sidarjo', 'jason', 'e10adc3949ba59abbe56e057f20f883e', 'Admin', '1', '2021-03-59', NULL, NULL);
INSERT INTO `tbl_user` VALUES ('b48d3e04-3fc7-497b-8b33-8ba0639ee230', 'Budi Saja', '12345', 'e10adc3949ba59abbe56e057f20f883e', 'Siswa', '1', '2021-03-42', NULL, NULL);

SET FOREIGN_KEY_CHECKS = 1;
